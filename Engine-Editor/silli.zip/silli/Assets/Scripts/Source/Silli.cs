﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using eg;

namespace Sandbox
{
    public class Silli : DefaultBehaviour
    {
        public float flolcik;
        public float flolcik2 = 45f;
        public int intidzer;
        public int intidzer2 = 53;
        public bool bulian;
        public Vector2 vektordwa;
        public Vector3 vektortrzy;
        public Vector4 vektorczetery;
        void OnCreate()
        {
            Console.WriteLine("sooooo silli");
        }

        void OnUpdate(float ts)
        {
            
        }

    }
}
